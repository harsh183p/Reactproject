const { json } = require('express')
const Message = require('../helper/message')
const products = require('../models/products')
const Products= require('../models/products')





exports.productadd=(req,res)=>{
  
  try{  const{name,desc,ldesc,price}=req.body
   const record= new Products({ name:name,desc:desc,ldesc:ldesc,price:price})
   record.save()
 res.json({
    status:Message.code201,
Message:Message.message201,
apiData:record

 })     
}catch(error){
    res.json({
status:Message.code400,
Message:Message.message400

    })
}
    }
      
    exports.allproducts=async(req,res)=>{
        try{
            const records=await products.find()
            res.json({
                status:Message.code200,
                message:Message.message200,
                apiData:records
            })
        }catch(error){
            res.json({
                status:Message.code500,
                message:error.message,
            })
        }
    }
    exports.singleproduct=async(req,res)=>{
        const id=req.params.id
        try{
          const record=  await products.findById(id)
res.json({
    status:Message.code200,
    message:Message.message200,
    apiData:record
})
        }catch(error){
res.json({
    status:Message.code500,
    message:Message.message500,
    
})

        }
    }
    exports.update=async(req,res)=>{
        const id=req.params.id
        const {name,desc,ldesc,price,status}=(req.body)
try{
await Products.findByIdAndUpdate(id,{name:name,desc:desc,ldesc:ldesc,price:price,status:status
})
res.json({
    status:Message.code200,
    message:Message.messageUpdate,

})
}catch(error){
   res.json({
    status:Message.code400,
    message:Message.message400,
   })
}

  }
  exports.productinstock=async(req,res)=>{
    try{
const record= await products.find({status:'IN STOCK'})
res.json({
    status:Message.code200,
    message:Message.message200,
    apiData:record
})
    }catch(error){
        res.json({
            status:Message.code500,
            message:Message.message500,
            })
    }
  }

  exports.productbyid=async(req,res)=>{
    const{ids}=(req.body)
    try{
     const record=await Products.find({_id:{$in:ids}})
     res.json({
        status:Message.code200,
        apiData:record
     })
  }catch{
req.json({
    status:Message.code500,
    message:Message.message500
})
  }
  }