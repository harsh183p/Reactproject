

const clientmessages={
    code200:200,
    message200:'success',
    code201:201,
    message201:'successffuly created',
    code400:400,
message400:'bad request',
code500:500,
message500:'Internal Server error',
messageUpdate:'successfully Updated'
}

module.exports=clientmessages