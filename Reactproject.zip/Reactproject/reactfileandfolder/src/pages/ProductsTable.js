import { Link } from "react-router-dom";

function Producttable(props) {
    const {data}=(props)
    return ( 
        <table className="table table-hover">
        <thead>
            <tr>
            <th>S.No</th>
                <th>Product Name</th>
                <th>Product Description</th>
                <th>Product Long Description</th>
                <th>Product Price</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
            <tbody>
            
            {data.map((result,key)=>(
<tr key={result._id}>
    <td>{key+1}</td>
    <td>{result.name}</td>
    <td>{result.desc}</td>
    <td>{result.ldesc}</td>
    <td>{result.price}</td>
    <td>{result.status}</td>
    <td><Link to={`/productupdate/${result._id}`}>Update</Link></td>
    </tr>

            ))}
                
            </tbody>
        </table>
     );
}

export default Producttable;