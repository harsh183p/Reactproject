import Loginpage from "../pages/Loginpage";

function Login() {
    return ( 
        <Loginpage/>
     );
}

export default Login;