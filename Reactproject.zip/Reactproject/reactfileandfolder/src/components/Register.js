
import { useState } from "react"
import { Link } from "react-router-dom"



function Register() {
    const [username,setUsername]= useState('')
    const [password,setPassword]= useState('')
    const [message,setMessage]= useState('')
       function handleform(e){
     e.preventDefault()
     const formdata={username,password}
     fetch('/api/reg',{
         method:'POST',
         headers:{"Content-Type":"application/json"},
         body:JSON.stringify(formdata)
     }).then((result)=>{return result.json()}).then((data)=>{
      
     if(data.status===201){
      setMessage(data.message)
     }else if(data.status){
      setMessage(`${data.apiData} Username already taken`)
     }
     else{
      setMessage(data.message)
     }
     })
  }
    return (
        <section id="register">
        <div className="container">
        <div className="row">
        <div className="col-md-4"></div>
        <div className="col-md-4">
            <h2>Register</h2>
            {message}
            <form onSubmit={(e)=>{handleform(e)}}>
                <label>Username/Email</label>
                <input type="text" 
                value={username}
                onChange={(e)=>{setUsername(e.target.value)}}
                className="form-control "/>
                <label>Password</label>
                <input type="text" 
                value={password}
                onChange={(e)=>{setPassword(e.target.value)}}
                className="form-control "/>
                <button type="submit" className=" btn btn-success mt-2 mb-2 form-control ">Register</button>
                
                <Link to='/'>have account? click here</Link>
            </form>
          
            
          
        </div>
        <div className="col-md-4"></div>
            </div>
        </div>
        </section>
      );
}

export default Register;