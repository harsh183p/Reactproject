import { useContext, useEffect, useState } from "react";
import { Contextapi } from "../pages/Contextapi";
import { useNavigate } from "react-router-dom";


function Cart() {
const navigate=useNavigate()
    let totalamount=0
    const{cart,setCart}=useContext(Contextapi)
    const[productId,setProductId]=useState([])
    const [message,setMessage]=useState('')
    useEffect(()=>{
        if(!cart.item){
            return
        }
               fetch('/api/productbyid',{
            method:"POST",
            headers:{"Content-Type":"application/json"},
            body:JSON.stringify({ids:Object.keys(cart.item)})
        }).then((result)=>{return result.json()}).then((data)=>{
             console.log(data)
            if(data.status===200){
setProductId(data.apiData)
            }else{
setMessage(data.message)
            }

        })
    },[])

    function handleqnty(id){
        return cart.item[id]
    }

    function handleprice(id,price){
        totalamount +=handleqnty(id)*price
      return  handleqnty(id)*price
    }

function handleincrement(e,id){
    let currentqnty=handleqnty(id)
    let _cart={...cart}
_cart.item[id]= currentqnty+1
_cart.totalitems +=1
setCart(_cart)
}

function handledecrement(e,id){
    let currentqnty=handleqnty(id)
    let _cart={...cart}
    if(_cart.item[id]===1){
        return
    }
_cart.item[id]= currentqnty-1
_cart.totalitems -=1
setCart(_cart)
}

function handlecheckout(e){
    // fetch('/') Payment api
    // fetch() DB api
    window.localStorage.setItem('cart','')
    setCart(window.localStorage.getItem('cart'))
    navigate('/products')}

  


      

    

    
    return ( 
   <div className="container">
     <div className="row">
     <div className="col-md-12">
     {productId.length?
        <table className="table table-hover">
            <thead>
                <tr>
                    <th>S.No</th>
                    <th>Product Name</th>
                    <th>Product Quantity</th>
                     <th>Product Price</th>
                     <th>Product Delete</th>
                </tr>
            </thead>

            <tbody>
            {productId.map((result,key)=>(
                <tr>
                <td>{key+1}</td>
                <td>{result.name}</td>
                <td><button onClick={(e)=>{handleincrement(e,result._id)}}>+</button>{handleqnty(result._id)}<button onClick={(e)=>{handledecrement(e,result._id)}}>-</button></td>
                <td>{handleprice(result._id,result.price)}</td>
                <td><button className="btn btn-danger"> Delete</button></td>
                </tr>
            ))}<tr><td><h4>Totalamount:</h4></td><td colSpan={"4"}>Rs. {totalamount}</td></tr>
            <tr><td colSpan={'5'} ><button onClick={(e)=>{handlecheckout(e)}} className="form-control btn btn-info">CheckOut</button></td></tr>
             
           
            </tbody>
        </table>
        :
        <h2><img src="cart.png" alt="" className="mx-auto d-block mt-5"/></h2>}
     </div>
     </div>
   </div>
     );
}

export default Cart;