import Productstr from "./productstr";
import {useEffect, useState} from 'react'

function Products() {

   const[products,setProducts]=useState([])
   const [message,setMessage]=useState('')
    useEffect(()=>{
        fetch('/api/productinstock').then((result)=>{return result.json()}).then((data)=>{
        console.log(data)
        if(data.status===200){
            setProducts(data.apiData)
        }else{
    setMessage(data.message)
        }
        })
            },[])

    return ( 
        
     <section id="dashboard">
        {message}
        <div className="container mt-2">
        <div className="row">
        {products.map((result)=>(

<Productstr product={result}/>

))}
            
       
      
        </div>
        </div>
    </section>
    


     );
}

export default Products;