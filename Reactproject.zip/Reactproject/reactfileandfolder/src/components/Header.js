import { useContext } from "react";
import { Contextapi } from "../pages/Contextapi";
import { Link, useNavigate } from "react-router-dom";

function Header() {
    const navigate=useNavigate()
    const{loginname,setLoginname,cart}=useContext(Contextapi)
     function handlelogout(e){
window.localStorage.removeItem('email')
setLoginname(window.localStorage.getItem('email'))
navigate('/')
    }
    return ( 
        <>
        {loginname?
<section id="header">
    <div className="container">
    <div className="row">
    <div className="col-md-8"><h4>Welcom {loginname}</h4></div>
    <div className="col-md-4">
    <Link to="/products"> <button className="btn btn-warning ms-2" >Products</button></Link>
   <Link to="/Cart"> <button className="btn btn-info" >Cart-{!cart.totalitems?0:cart.totalitems }</button></Link>
    <button className="btn btn-danger me-2" onClick={(e)=>{handlelogout(e)}}>Logout</button>
    </div>
    </div>
    </div>
</section>
:
<></>
        }
        </>
     );
}

export default Header;