import { Link } from "react-router-dom";
import Left from "./Left";
import { useEffect, useState } from "react";
import Producttable from "../pages/ProductsTable";


function Adminproducts() {
   const [products,setProducts]=useState([])
   const [message,setMessage]=useState('')
    useEffect(()=>{
fetch('/api/allproducts').then((result)=>{return result.json()}).then((data)=>{
    console.log(data)
 if(data.status===200){
setProducts(data.apiData)
 }else{
    setMessage(data.message)
 }


})
    },[])
        return ( 
        <section>
            <div className="container">
            <div className="row">
            <Left/>
            <div className="col-md-9">
        <h2>products Management</h2>  
        
        <Link to='/productadd'><button className="btn btn-warning form-control">Product Add Here</button></Link>
        {message}
      <Producttable data={products}/>
        </div>
            </div>
            </div>
        </section>
     );
}

export default Adminproducts;