import { BrowserRouter as Router,Route,Routes} from 'react-router-dom'
import Login from './components/Login';
import Register from './components/Register';
import Dashboard from './components/Dashboard';
import Header from './components/Header';
import Adminproducts from './components/Adminproducts';
import Productadd from './components/Productadd';
import { Contextapi } from './pages/Contextapi';
import { useEffect, useState } from 'react';
import Productupdate from './components/Productupdate';
import Products from './components/products';
import Cart from './components/Cart';

 



function App() {
  const[cart,setCart]=useState('')
  const [loginname,setLoginname]=useState(window.localStorage.getItem('email'))
  useEffect(()=>{
    window.localStorage.setItem('cart',JSON.stringify(cart))
  },[cart])
  return ( 
   <>
   <Router>
   <Contextapi.Provider value={{loginname,setLoginname,cart,setCart}}>
<Header/>
    <Routes>
      <Route path='/' element={<Login/>}></Route>
      <Route path='/reg' element={<Register/>}></Route>
      <Route path='/dashboard' element={<Dashboard/>}></Route>
      <Route path='/adminproducts' element={<Adminproducts/>}></Route>
      <Route path='/productadd' element={<Productadd/>}></Route>
      <Route path='/productupdate/:id' element={<Productupdate/>}></Route>
      <Route path='/products' element={<Products/>}></Route>
      <Route path='/Cart' element={<Cart/>}></Route>
    </Routes>
    </Contextapi.Provider>
    </Router>
   </>
   );
}

export default App;